import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;

/**
 * Created by Naga on 13-03-2017.
 */
@WebServlet(name = "ImageService", urlPatterns = "/ImageService")
public class ImageService extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        StringBuilder buffer = new StringBuilder();
        BufferedReader reader = req.getReader();
        String response="";
        String line;
        while ((line = reader.readLine()) != null) {
            buffer.append(line);
        }
        String data = buffer.toString();
        System.out.println(data);
        String output = "";
        JSONObject params = new JSONObject(data);
        JSONObject result = params.getJSONObject("result");
        JSONObject parameters = result.getJSONObject("parameters");
        if (parameters.get("flowers").toString().equals("flowers")) {
            JSONObject jsonObject = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            jsonArray.put("https://static.pexels.com/photos/27714/pexels-photo-27714.jpg");
            jsonArray.put("https://static.pexels.com/photos/4825/red-love-romantic-flowers.jpg");
            jsonArray.put("https://static.pexels.com/photos/169193/pexels-photo-169193.jpeg");
            jsonArray.put("https://static.pexels.com/photos/60628/flower-garden-blue-sky-hokkaido-japan-60628.jpeg");
            jsonArray.put("https://static.pexels.com/photos/54630/japanese-cherry-trees-flowers-spring-japanese-flowering-cherry-54630.jpeg");
            jsonArray.put("https://static.pexels.com/photos/87452/flowers-background-butterflies-beautiful-87452.jpeg");
            jsonObject.put("data", jsonArray);
            output = jsonObject.toString();
            Data data_ob = Data.getInstance();
            data_ob.setData(output);
            data_ob.setFlag(true);
            JSONObject js = new JSONObject();
            js.put("speech", "flowers are displayed");
            js.put("displayText", "flowers are displayed");
            js.put("source", "image database");
            response = js.toString();
        }
        else if (parameters.get("flowers").toString().equals("rose")) {
            JSONObject jsonObject = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            jsonArray.put("https://static.pexels.com/photos/15239/flower-roses-red-roses-bloom.jpg");
            jsonArray.put("https://static.pexels.com/photos/26071/pexels-photo-26071.jpg");
            jsonArray.put("https://static.pexels.com/photos/122734/pexels-photo-122734.jpeg");
            jsonArray.put("https://static.pexels.com/photos/65619/roses-pink-family-rose-family-65619.jpeg");
            jsonArray.put("https://static.pexels.com/photos/67636/rose-blue-flower-rose-blooms-67636.jpeg");
            jsonArray.put("https://static.pexels.com/photos/196664/pexels-photo-196664.jpeg");
            jsonObject.put("data", jsonArray);
            output = jsonObject.toString();
            Data data_ob = Data.getInstance();
            data_ob.setData(output);
            data_ob.setFlag(true);
            JSONObject js = new JSONObject();
            js.put("speech", "roses are displayed");
            js.put("displayText", "roses are displayed");
            js.put("source", "image database");
            response = js.toString();
        }
        else if (parameters.get("flowers").toString().equals("tulip")){
            JSONObject jsonObject = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            jsonArray.put("https://static.pexels.com/photos/110138/pexels-photo-110138.jpeg");
            jsonArray.put("https://static.pexels.com/photos/69776/tulips-bed-colorful-color-69776.jpeg");
            jsonArray.put("https://static.pexels.com/photos/29888/pexels-photo-29888.jpg");
            jsonArray.put("https://static.pexels.com/photos/159406/tulips-netherlands-flowers-bloom-159406.jpeg");
            jsonArray.put("https://static.pexels.com/photos/62279/pexels-photo-62279.jpeg");
            jsonArray.put("https://static.pexels.com/photos/52571/pexels-photo-52571.jpeg");
            jsonObject.put("data", jsonArray);
            output = jsonObject.toString();
            Data data_ob = Data.getInstance();
            data_ob.setData(output);
            data_ob.setFlag(true);
            JSONObject js = new JSONObject();
            js.put("speech", "tulips are displayed");
            js.put("displayText", "tulips are displayed");
            js.put("source", "image database");
            response = js.toString();
        }
        else if (parameters.get("flowers").toString().equals("jasmine")){
            JSONObject jsonObject = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            jsonArray.put("https://pimg.tradeindia.com/00471325/b/2/Fresh-Jasmine-Flower-suppliers.jpg");
            jsonArray.put("https://i.ytimg.com/vi/w3C-Eqrkebw/hqdefault.jpg");
            jsonArray.put("https://s-media-cache-ak0.pinimg.com/736x/71/15/2f/71152fea92135d4802a539d6af2f19a2.jpg");
            jsonArray.put("https://s-media-cache-ak0.pinimg.com/736x/6b/2e/47/6b2e4730ce20dcd2b4320969bd28e247.jpg");
            jsonArray.put("https://cdn.shutterstock.com/shutterstock/videos/13176818/thumb/8.jpg");
            jsonArray.put("https://cdn.shutterstock.com/shutterstock/videos/3832994/thumb/2.jpg");
            jsonObject.put("data", jsonArray);
            output = jsonObject.toString();
            Data data_ob = Data.getInstance();
            data_ob.setData(output);
            data_ob.setFlag(true);
            JSONObject js = new JSONObject();
            js.put("speech", "jasmines are displayed");
            js.put("displayText", "jasmines are displayed");
            js.put("source", "image database");
            response = js.toString();
        }
        else if (parameters.get("null").toString().equals("clear")){
            Data data_ob = Data.getInstance();
            JSONObject js1 = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            jsonArray.put(" ");
            js1.put("data", jsonArray);
            data_ob.setData(js1.toString());
            data_ob.setFlag(true);
            JSONObject js = new JSONObject();
            js.put("speech", "screen is cleared");
            js.put("displayText", "screen is cleared");
            js.put("source", "image database");
            response = js.toString();
        }
        resp.setHeader("Content-type", "application/json");
        resp.getWriter().write(response);
    }
}
